import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

const apiExamples: Record<string, string> = {
  "RTP Send": "POST https://api.bank.com/rtp/send",
  "Balance Enquiry": "GET https://api.bank.com/account/balance",
  "Status Check": "GET https://api.bank.com/payment/status",
  "RTP Received": "GET https://api.bank.com/rtp/received",
};

const useCases: Record<string, string> = {
  "RTP Send":
    "Use this endpoint to initiate a real-time payment to a beneficiary. Useful for instant fund transfers.",
  "Balance Enquiry":
    "Check your current account balance instantly. Useful for verifying available funds before making a transaction.",
  "Status Check":
    "Check the status of a previously initiated payment. Useful for tracking payment progress or troubleshooting.",
  "RTP Received":
    "View all real-time payments received in your account. Useful for reconciliation and notifications.",
};

const Document: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const card = location.state as
    | { image: string; heading: string; price: string }
    | undefined;
  const api = card
    ? apiExamples[card.heading] || "GET https://api.bank.com/example"
    : "";
  const useCase = card
    ? useCases[card.heading] || "No use case available."
    : "";

  const handleCopy = () => {
    // Only copy the URL, not the method
    const url = api.split(" ").pop() || api;
    navigator.clipboard.writeText(url);
  };

  const handleGenerateApiKey = () => {
    if (card) {
      navigate("/payment", { state: { ...card, api, useCase } });
    }
  };

  if (!card) return <div className="text-center mt-10">No API selected.</div>;

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] p-6">
      <div className="flex flex-col items-center mb-6 bg-white p-6 rounded shadow-md w-full max-w-md">
        <img
          src={card.image}
          alt={card.heading}
          className="w-24 h-24 object-contain rounded mb-2"
        />
        <h2 className="text-2xl font-bold mb-2">{card.heading}</h2>
        <p className="text-gray-600 mb-4 text-center">{card.price}</p>
        <div className="w-full flex items-center bg-gray-100 rounded px-3 py-2 mb-4">
          <span className="flex-1 text-sm font-mono text-gray-800">{api}</span>
          <button
            className="ml-2 px-2 py-1 bg-blue-500 text-white rounded text-xs hover:bg-blue-600"
            onClick={handleCopy}
          >
            Copy
          </button>
        </div>
        <div className="w-full mt-2">
          <h3 className="text-lg font-semibold mb-1">Use Case</h3>
          <p className="text-gray-700 text-sm">{useCase}</p>
        </div>
        <button
          className="mt-6 px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700 w-full"
          onClick={handleGenerateApiKey}
        >
          Generate API Key
        </button>
      </div>
    </div>
  );
};

export default Document;
