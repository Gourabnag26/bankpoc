import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const Payment: React.FC = () => {
  const [status, setStatus] = useState<"idle" | "pending" | "success" | "fail">(
    "idle"
  );
  const [showToast, setShowToast] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const card = location.state as
    | {
        image: string;
        heading: string;
        price: string;
        api?: string;
        useCase?: string;
      }
    | undefined;

  // Generate a random API key and set user in localStorage only once on success
  const apiKey = React.useMemo(
    () =>
      Math.random().toString(36).substring(2, 10).toUpperCase() +
      "-" +
      Math.random().toString(36).substring(2, 10).toUpperCase(),
    [showSummary, status]
  );
  useEffect(() => {
    if (showSummary && status === "success") {
      localStorage.setItem("apiKey", apiKey);
    }
  }, [showSummary, status, apiKey]);

  useEffect(() => {
    if (status === "success") {
      setShowToast(true);
      setShowSummary(true);
      const timer = setTimeout(() => {
        setShowToast(false);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [status]);

  const handleOption = (result: "success" | "fail") => {
    setStatus("pending");
    setTimeout(() => {
      setStatus(result);
    }, 1500);
  };

  const handleRetry = () => {
    setStatus("idle");
  };

  const handleGoBack = () => {
    setShowSummary(false);
    navigate("/");
  };

  if (status === "pending") {
    return (
      <div className="flex flex-col items-center justify-center h-96 w-full">
        <div className="flex flex-col items-center">
          <svg
            className="animate-spin h-16 w-16 text-blue-500 mb-4"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            ></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8v8z"
            ></path>
          </svg>
          <h2 className="text-xl font-semibold text-gray-700">Processing...</h2>
        </div>
      </div>
    );
  }

  if (showSummary && status === "success") {
    const handleCopyKey = () => {
      navigator.clipboard.writeText(apiKey);
    };
    const handleGoDashboard = () => {
      navigate("/"); // Change to your dashboard route if needed
    };
    return (
      <div className="flex flex-col items-center justify-center h-96 w-full relative">
        {showToast && (
          <div className="fixed top-6 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-6 py-2 rounded shadow-lg z-50 transition-all">
            Payment Successful!
          </div>
        )}
        <div className="flex flex-col items-center mb-6 bg-white p-6 rounded shadow-md">
          <h2 className="text-2xl font-bold text-green-600 mb-4">
            Payment Summary
          </h2>
          {card && (
            <>
              <img
                src={card.image}
                alt={card.heading}
                className="w-32 h-32 object-cover rounded mb-2"
              />
              <h3 className="text-lg font-semibold">{card.heading}</h3>
              <p className="text-blue-600 font-bold">{card.price}</p>
              {card.api && (
                <div className="w-full flex items-center bg-gray-100 rounded px-3 py-2 my-2">
                  <span className="flex-1 text-sm font-mono text-gray-800">
                    {card.api}
                  </span>
                </div>
              )}
              {card.useCase && (
                <div className="w-full mt-2">
                  <h3 className="text-lg font-semibold mb-1">Use Case</h3>
                  <p className="text-gray-700 text-sm">{card.useCase}</p>
                </div>
              )}
            </>
          )}
          <div className="w-full flex items-center bg-gray-100 rounded px-3 py-2 my-4">
            <span className="flex-1 text-sm font-mono text-gray-800">
              {apiKey}
            </span>
            <button
              className="ml-2 px-2 py-1 bg-blue-500 text-white rounded text-xs hover:bg-blue-600"
              onClick={handleCopyKey}
            >
              Copy
            </button>
          </div>
          <button
            className="mt-2 px-6 py-2 bg-purple-500 text-white rounded hover:bg-purple-600"
            onClick={handleGoDashboard}
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  if (status === "fail") {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        {card && (
          <div className="flex flex-col items-center mb-4">
            <h3 className="text-lg font-semibold">{card.heading}</h3>
            <p className="text-blue-600 font-bold">{card.price}</p>
            {card.api && (
              <div className="w-full flex items-center bg-gray-100 rounded px-3 py-2 my-2">
                <span className="flex-1 text-sm font-mono text-gray-800">
                  {card.api}
                </span>
              </div>
            )}
            {card.useCase && (
              <div className="w-full mt-2">
                <h3 className="text-lg font-semibold mb-1">Use Case</h3>
                <p className="text-gray-700 text-sm">{card.useCase}</p>
              </div>
            )}
          </div>
        )}
        <h2 className="text-2xl font-bold text-red-600 mb-4">
          Payment Failed!
        </h2>
        <div className="flex gap-4 mt-4">
          <button
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            onClick={handleRetry}
          >
            Retry
          </button>
          <button
            className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
            onClick={() => navigate("/")}
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center h-64">
      {card && (
        <div className="flex flex-col items-center mb-6">
          <img
            src={card.image}
            alt={card.heading}
            className="w-32 h-32 object-cover rounded mb-2"
          />
          <h3 className="text-lg font-semibold">{card.heading}</h3>
          <p className="text-blue-600 font-bold">{card.price}</p>
          {card.api && (
            <div className="w-full flex items-center bg-gray-100 rounded px-3 py-2 my-2">
              <span className="flex-1 text-sm font-mono text-gray-800">
                {card.api}
              </span>
            </div>
          )}
          {card.useCase && (
            <div className="w-full mt-2">
              <h3 className="text-lg font-semibold mb-1">Use Case</h3>
              <p className="text-gray-700 text-sm">{card.useCase}</p>
            </div>
          )}
        </div>
      )}
      <h2 className="text-xl font-semibold mb-6">Choose Payment Result</h2>
      <div className="flex gap-6">
        <button
          className="px-6 py-2 bg-green-500 text-white rounded hover:bg-green-600"
          onClick={() => handleOption("success")}
        >
          Pass
        </button>
        <button
          className="px-6 py-2 bg-red-500 text-white rounded hover:bg-red-600"
          onClick={() => handleOption("fail")}
        >
          Fail
        </button>
      </div>
    </div>
  );
};

export default Payment;
