import React from "react";
import Card from "./Card";

// Bank gateway API actions
const cardData = [
  {
    image: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
    heading: "RTP Send",
    price: "Initiate a real-time payment send request",
  },
  {
    image: "https://cdn-icons-png.flaticon.com/512/3135/3135712.png",
    heading: "Balance Enquiry",
    price: "Check your account balance",
  },
  {
    image: "https://cdn-icons-png.flaticon.com/512/3135/3135706.png",
    heading: "Status Check",
    price: "Check the status of a payment",
  },
  {
    image: "https://cdn-icons-png.flaticon.com/512/3135/3135708.png",
    heading: "RTP Received",
    price: "View received real-time payments",
  },
];

function CardList() {
  return (
    <div style={{ display: "flex", gap: "16px" }}>
      {cardData.map((item, idx) => (
        <Card
          key={idx}
          image={item.image}
          heading={item.heading}
          price={item.price}
        />
      ))}
    </div>
  );
}

export default CardList;
