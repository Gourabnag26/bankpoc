import React from "react";

const Documentation: React.FC = () => (
  <div className="w-full min-h-[90vh] flex justify-center items-start bg-gradient-to-br from-blue-50 to-blue-100 py-16 px-2">
    <div className="bg-white/95 rounded-2xl shadow-2xl border border-blue-200 max-w-4xl w-full p-12 md:p-20 lg:p-24 mx-auto text-left">
      <h1 className="text-5xl font-extrabold text-blue-800 mb-8 flex items-center gap-3">
        <span role="img" aria-label="book">
          📘
        </span>{" "}
        React Project Setup with Vite and TypeScript
      </h1>
      <p className="text-xl mb-10 text-gray-800 font-semibold">
        This guide walks you through setting up a modern React project using
        <a
          href="https://vitejs.dev/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-700 underline ml-1 font-bold"
        >
          Vite
        </a>
        and
        <a
          href="https://www.typescriptlang.org/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-700 underline ml-1 font-bold"
        >
          TypeScript
        </a>
        , with development in
        <a
          href="https://code.visualstudio.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-700 underline ml-1 font-bold"
        >
          Visual Studio Code
        </a>
        .
      </p>
      <h2 className="text-3xl font-bold text-blue-700 mt-12 mb-4">
        🧰 Prerequisites
      </h2>
      <ul className="mb-10 list-disc list-inside text-gray-800 text-lg font-semibold space-y-2">
        <li>
          Node.js (v14+):{" "}
          <a
            href="https://nodejs.org/"
            className="text-blue-700 underline font-bold"
          >
            nodejs.org
          </a>
        </li>
        <li>
          VS Code:{" "}
          <a
            href="https://code.visualstudio.com/"
            className="text-blue-700 underline font-bold"
          >
            code.visualstudio.com
          </a>
        </li>
      </ul>
      <h2 className="text-3xl font-bold text-blue-700 mt-12 mb-4">
        🎯 Why Vite Instead of CRA?
      </h2>
      <ul className="mb-10 list-disc list-inside text-gray-800 text-lg font-semibold space-y-2">
        <li>
          ⚡️ <b>Instant server start</b> using native ES modules
        </li>
        <li>
          🔁 <b>Lightning-fast hot module replacement (HMR)</b>
        </li>
        <li>🧱 Smaller, optimized production builds</li>
      </ul>
      <h2 className="text-3xl font-bold text-blue-700 mt-12 mb-4">
        🧠 Why TypeScript Instead of JavaScript?
      </h2>
      <ul className="mb-10 list-disc list-inside text-gray-800 text-lg font-semibold space-y-2">
        <li>
          ✅ <b>Static type checking</b> to catch errors early
        </li>
        <li>
          🧠 <b>Improved developer tooling</b> (auto-completion, refactoring)
        </li>
        <li>📦 Better scalability for large codebases</li>
      </ul>
      <h2 className="text-3xl font-bold text-blue-700 mt-12 mb-4">
        🚀 Steps to Create a React App Using Vite + TypeScript
      </h2>
      <ol className="mb-10 list-decimal list-inside text-gray-800 text-lg font-semibold space-y-2">
        <li>
          Create the Project:
          <br />
          <code className="bg-gray-100 px-3 py-1 rounded text-lg font-bold">
            npm create vite@latest my-react-app -- --template react-ts
          </code>
        </li>
        <li>
          Navigate into the Project Directory:
          <br />
          <code className="bg-gray-100 px-3 py-1 rounded text-lg font-bold">
            cd my-react-app
          </code>
        </li>
        <li>
          Install Dependencies:
          <br />
          <code className="bg-gray-100 px-3 py-1 rounded text-lg font-bold">
            npm install
          </code>
        </li>
        <li>
          Start the Development Server:
          <br />
          <code className="bg-gray-100 px-3 py-1 rounded text-lg font-bold">
            npm run dev
          </code>
        </li>
      </ol>
      <p className="mb-10 text-gray-800 text-lg font-semibold">
        This will start the app at{" "}
        <code className="bg-gray-100 px-3 py-1 rounded font-bold">
          http://localhost:5173
        </code>{" "}
        (or the next available port).
      </p>
      <h2 className="text-3xl font-bold text-blue-700 mt-12 mb-4">
        📁 Project Structure Overview
      </h2>
      <pre className="bg-gray-100 rounded p-6 text-base font-bold overflow-x-auto mb-10 text-gray-800 text-left">
        <code>{`my-react-app/
├── public/               # Static assets
├── src/                  # Source code
│   ├── App.tsx           # Main App component
│   ├── main.tsx          # Entry point
│   └── ...
├── index.html            # HTML template
├── tsconfig.json         # TypeScript configuration
├── vite.config.ts        # Vite configuration
└── package.json          # Project metadata and scripts`}</code>
      </pre>
      <h2 className="text-3xl font-bold text-blue-700 mt-12 mb-4">
        ✅ Next Steps
      </h2>
      <ul className="mb-10 list-disc list-inside text-gray-800 text-lg font-semibold space-y-2">
        <li>
          🎨 <b>Styling</b>: Add Tailwind CSS or Sass
        </li>
        <li>
          🌐 <b>Routing</b>: Install{" "}
          <code className="bg-gray-100 px-2 py-1 rounded font-bold">
            react-router-dom
          </code>{" "}
          for page navigation
        </li>
        <li>
          🧠 <b>State Management</b>: Use Redux, Zustand, or React Context
        </li>
        <li>
          🚀 <b>Deployment</b>: Deploy to Vercel, Netlify, or AWS
        </li>
      </ul>
      <h2 className="text-3xl font-bold text-blue-700 mt-12 mb-4">
        📌 Useful Commands
      </h2>
      <table className="w-full mb-10 border border-blue-200 rounded overflow-hidden text-lg font-bold">
        <thead className="bg-blue-100">
          <tr>
            <th className="py-3 px-5 text-left">Command</th>
            <th className="py-3 px-5 text-left">Description</th>
          </tr>
        </thead>
        <tbody>
          <tr className="border-t border-blue-100">
            <td className="py-3 px-5">
              <code>npm run dev</code>
            </td>
            <td className="py-3 px-5">Start the development server</td>
          </tr>
          <tr className="border-t border-blue-100">
            <td className="py-3 px-5">
              <code>npm run build</code>
            </td>
            <td className="py-3 px-5">Build the app for production</td>
          </tr>
          <tr className="border-t border-blue-100">
            <td className="py-3 px-5">
              <code>npm run preview</code>
            </td>
            <td className="py-3 px-5">Preview the production build</td>
          </tr>
        </tbody>
      </table>
      <h2 className="text-3xl font-bold text-blue-700 mt-12 mb-4">
        🐳 How to Containerize with Docker
      </h2>
      <p className="text-lg font-semibold text-gray-800 mb-6">
        Easily run your React app anywhere by packaging it in a Docker
        container. Follow these steps:
      </p>
      <ol className="mb-10 list-decimal list-inside text-gray-800 text-lg font-semibold space-y-2">
        <li>
          <b>
            Create a <code>Dockerfile</code> in your project root:
          </b>
          <pre className="bg-gray-100 rounded p-4 text-base font-bold overflow-x-auto mt-2 mb-2 text-gray-800 text-left">
            <code>{`# Stage 1: Build
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

# Stage 2: Serve
FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]`}</code>
          </pre>
        </li>
        <li>
          <b>Build the Docker image:</b>
          <br />
          <code className="bg-gray-100 px-3 py-1 rounded text-lg font-bold">
            docker build -t my-react-app .
          </code>
        </li>
        <li>
          <b>Run the container:</b>
          <br />
          <code className="bg-gray-100 px-3 py-1 rounded text-lg font-bold">
            docker run -p 8080:80 my-react-app
          </code>
        </li>
      </ol>
      <p className="mb-10 text-gray-800 text-lg font-semibold">
        Your app will be available at{" "}
        <code className="bg-gray-100 px-3 py-1 rounded font-bold">
          http://localhost:8080
        </code>
        .
      </p>
      <hr className="my-12 border-blue-200" />
    </div>
  </div>
);

export default Documentation;
