import React from "react";
import { useNavigate } from "react-router-dom";

interface CardProps {
  image: string;
  heading: string;
  price: string;
}

const Card: React.FC<CardProps> = ({ image, heading, price }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate("/document", { state: { image, heading, price } });
  };

  return (
    <div
      className="bg-white rounded-lg shadow-md p-4 w-60 flex flex-col items-center hover:shadow-xl transition-shadow cursor-pointer"
      onClick={handleClick}
    >
      <div className="w-full h-32 flex items-center justify-center mb-4 overflow-hidden rounded-md bg-gray-100">
        <img
          src={image}
          alt={heading}
          className="object-contain w-full h-full"
        />
      </div>
      <h3 className="text-lg font-semibold mb-2">{heading}</h3>
      <p className="text-blue-600 font-bold text-base text-center">{price}</p>
    </div>
  );
};

export default Card;
