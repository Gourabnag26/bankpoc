import React, { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

const sampleUsage = [
  { day: "Mon", usage: 12 },
  { day: "Tue", usage: 18 },
  { day: "Wed", usage: 9 },
  { day: "Thu", usage: 15 },
  { day: "Fri", usage: 20 },
  { day: "Sat", usage: 7 },
  { day: "Sun", usage: 11 },
];

const sampleLogs = [
  { time: "2025-07-09 10:12", message: "RTP Send failed: Insufficient funds" },
  {
    time: "2025-07-08 16:45",
    message: "Status Check failed: Invalid transaction ID",
  },
  {
    time: "2025-07-07 09:30",
    message: "Balance Enquiry failed: Account locked",
  },
];

const Dashboard: React.FC = () => {
  const [apiKey, setApiKey] = useState<string | null>(null);

  useEffect(() => {
    setApiKey(localStorage.getItem("apiKey"));
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] p-0 w-full overflow-x-hidden">
      <div className="bg-white p-10 rounded shadow-md w-screen mb-8 max-w-none mx-0">
        <h2 className="text-3xl font-bold mb-4 text-center">
          Welcome to your Dashboard!
        </h2>
        <div className="mb-6 text-center">
          <span className="font-semibold text-lg">Your API Key:</span>
          <span className="ml-2 font-mono text-blue-700 bg-gray-100 px-4 py-2 rounded text-lg">
            {apiKey || "Not generated yet"}
          </span>
        </div>
        <div className="mb-10">
          <h3 className="text-xl font-semibold mb-4">API Daily Usage</h3>
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={sampleUsage}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="usage" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div>
          <h3 className="text-xl font-semibold mb-4">API Failure Log</h3>
          <ul className="bg-gray-50 rounded p-6">
            {sampleLogs.map((log, idx) => (
              <li key={idx} className="mb-3 text-base text-red-600">
                <span className="font-mono text-gray-700">[{log.time}]</span>{" "}
                {log.message}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
