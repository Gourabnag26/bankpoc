import { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  useLocation,
} from "react-router-dom";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import CardList from "./components/cardList";
import Payment from "./components/Payment";
import Document from "./components/document";
import Dashboard from "./components/Dashboard";
import Documentation from "./components/Documentation";

function AppContent() {
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [userExists, setUserExists] = useState(false);
  const location = useLocation();

  useEffect(() => {
    if (typeof window !== "undefined") {
      setApiKey(localStorage.getItem("apiKey"));
      setUserExists(!!localStorage.getItem("apiKey"));
    }
  }, []);

  // Update apiKey and userExists immediately on route change
  useEffect(() => {
    if (typeof window !== "undefined") {
      setApiKey(localStorage.getItem("apiKey"));
      setUserExists(!!localStorage.getItem("apiKey"));
    }
  }, [location]);

  // Hide navbar on payment summary or when payment is made
  const hideNav =
    location.pathname === "/payment" &&
    location.state &&
    location.state.paymentMade;

  const handleLogout = () => {
    localStorage.clear();
    window.location.reload();
  };

  return (
    <>
      {!hideNav && (
        <header className="bg-gradient-to-r from-blue-700 to-blue-400 py-8 shadow-md mb-8 p-0 w-screen min-w-0 relative overflow-x-hidden">
          {/* Fixed Logout button in top right corner */}
          {userExists && (
            <button
              onClick={handleLogout}
              className="absolute top-6 right-10 bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-6 rounded shadow transition z-50"
            >
              Logout
            </button>
          )}
          <div className="w-screen flex flex-col items-center p-0 m-0 min-w-0 relative">
            <h1
              className="text-5xl font-extrabold text-white mb-2 drop-shadow-lg tracking-tight text-center"
              onClick={() => console.log("click")}
            >
              My Bank Payment API
            </h1>
            <nav className="flex gap-8 mt-4 p-0 m-0 w-screen min-w-0 justify-center">
              <Link
                to="/"
                className="text-white text-lg font-semibold hover:underline transition"
              >
                Home
              </Link>
              <Link
                to="/documentation"
                className="text-white text-lg font-semibold hover:underline transition"
              >
                Documentation
              </Link>
            </nav>
          </div>
        </header>
      )}
      <main className="pt-4 pb-12 min-h-[80vh] bg-gray-50 w-full flex justify-center max-w-full m-auto overflow-x-hidden">
        <div className="w-auto px-0 max-w-full">
          <Routes>
            {apiKey && <Route path="/" element={<Dashboard />} />}
            {!apiKey && <Route path="/" element={<CardList />} />}
            <Route path="/payment" element={<Payment />} />
            <Route path="/document" element={<Document />} />
            <Route path="/documentation" element={<Documentation />} />
          </Routes>
        </div>
      </main>
    </>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
